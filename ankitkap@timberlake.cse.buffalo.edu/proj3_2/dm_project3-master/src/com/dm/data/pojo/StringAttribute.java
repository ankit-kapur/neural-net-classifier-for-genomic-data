package com.dm.data.pojo;

import java.util.List;

public class StringAttribute extends Attribute {

    private List<String> data;

    public List<String> getData() {
        return data;
    }

    public void setData(List<String> data) {
        this.data = data;
    }
}
