package com.dm.data.pojo;

public interface LeafValue {

}
